# Summary

This project focuses on predicting employee performance ratings based on various workplace attributes. Using machine learning techniques, the model identifies key factors that influence performance, providing valuable insights for organizational decision-making.

The dataset used in this project includes features such as employee satisfaction, work-life balance, overtime, job role, and education background. After performing essential preprocessing steps like one-hot encoding (OHE) and feature selection, a Gradient Boosting Classifier was trained to predict employee performance ratings with high accuracy.

The model's performance was evaluated using appropriate metrics, and the top features influencing performance ratings were identified. This project demonstrates how data science methodologies can be applied to optimize employee management and improve overall organizational performance.

By leveraging data insights, the model can assist in hiring decisions and support human resource management strategies. The results highlight the importance of job satisfaction, work-life balance, and other factors in determining employee performance, which can aid in creating a better working environment and enhancing employee well-being.
